public class Main {
    public static void main(String[] args) {
        System.out.println("TASK 1: Protection Proxy");
        Image guestImage = new ProxyImage("salary_sheet.png", "GUEST");
        guestImage.show();

        Image adminImage = new ProxyImage("salary_sheet.png", "ADMIN");
        adminImage.show();

        System.out.println("\nTASK 2: View Counter Proxy");
        Video catVideo = new ProxyVideo("Cat_Memes.mp4");
        catVideo.play();
        catVideo.play();
        catVideo.play();

        System.out.println("\nTASK 3: School Wi-Fi Firewall");
        Internet schoolInternet = new SchoolProxyInternet();
        schoolInternet.connectTo("wikipedia.org");
        schoolInternet.connectTo("gaming.com");
    }
}